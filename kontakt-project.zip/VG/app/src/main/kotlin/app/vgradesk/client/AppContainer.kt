package app.vgradesk.client

import android.content.Context
import app.vgradesk.client.auth.AuthManager
import app.vgradesk.client.auth.TokenStore
import app.vgradesk.client.core.DiagnosticsLog
import app.vgradesk.client.core.NetworkMonitor
import app.vgradesk.client.core.SettingsStore
import app.vgradesk.client.data.ChatsRepository
import app.vgradesk.client.data.FeedRepository
import app.vgradesk.client.data.FilterStats
import app.vgradesk.client.data.ForYouRepository
import app.vgradesk.client.data.ProfileRepository
import app.vgradesk.client.data.VkChunkLoader
import app.vgradesk.client.net.VkApi
import app.vgradesk.client.rec.FilterConfig
import app.vgradesk.client.rec.Recommender
import app.vgradesk.client.rec.RecommenderStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

/** Простая ручная сборка зависимостей: без DI-фреймворка, чтобы не раздувать запуск и сборку. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    /** Живёт столько же, сколько процесс: сохранение обучения, наблюдение за настройками. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val diagnostics = DiagnosticsLog()
    val network = NetworkMonitor(appContext)

    val tokenStore = TokenStore(appContext)
    val settings = SettingsStore(appContext)
    val auth = AuthManager(tokenStore)
    val api = VkApi(auth, diagnostics)

    val filterStats = FilterStats()

    /** Актуальные настройки фильтра; пока DataStore читается, действуют безопасные значения по умолчанию. */
    val filterConfig: StateFlow<FilterConfig> =
        settings.filterConfig.stateIn(appScope, SharingStarted.Eagerly, FilterConfig())

    /** Обучение хранится только на устройстве, в закрытой папке приложения. */
    val recommender = Recommender(RecommenderStore(File(appContext.filesDir, "recommender.json")))

    private val chunkLoader = VkChunkLoader(api) { filterConfig.value }

    val profileRepo = ProfileRepository(api)
    val chatsRepo = ChatsRepository(api)
    val feedRepo = FeedRepository(chunkLoader, recommender, filterStats)
    val forYouRepo = ForYouRepository(chunkLoader, recommender, filterStats)

    private val saveRequests = Channel<Unit>(Channel.CONFLATED)

    init {
        // Небольшой файл (десятки килобайт) читается один раз при запуске, до показа интерфейса.
        recommender.load()
        recommender.onChanged = { saveRequests.trySend(Unit) }
        appScope.launch(Dispatchers.IO) {
            for (request in saveRequests) {
                delay(SAVE_DELAY_MS)
                recommender.flush()
            }
        }
    }

    /** Сохранить обучение немедленно (например, когда приложение уходит в фон). */
    fun persistNow() {
        appScope.launch(Dispatchers.IO) { recommender.flush() }
    }

    /**
     * Выход из аккаунта: токен удаляется, а обучение рекомендаций, счётчики и журнал очищаются,
     * чтобы данные разных аккаунтов не смешивались.
     */
    fun signOutAndWipe() {
        auth.signOut()
        filterStats.reset()
        diagnostics.clear()
        appScope.launch(Dispatchers.IO) { recommender.wipeStorage() }
    }

    private companion object {
        const val SAVE_DELAY_MS = 1_500L
    }
}
