pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Официальные репозитории VK ID SDK (см. README SDK: github.com/VKCOM/vkid-android-sdk)
        maven("https://artifactory-external.vkpartner.ru/artifactory/vkid-sdk-android/")
        maven("https://artifactory-external.vkpartner.ru/artifactory/maven/")
        maven("https://artifactory-external.vkpartner.ru/artifactory/vk-id-captcha/android/")
    }
}

rootProject.name = "Kontakt"
include(":app")
